// Array met winkelinformatie
const shops = [
  { name: "Bakkerij De Broodkorf", openingHour: 7, closingHour: 17 },
  { name: "Boekhandel Inkt & Papier", openingHour: 9, closingHour: 15 },
  { name: "Elektronica TechNerd", openingHour: 13, closingHour: 20 },
  { name: "Kledingwinkel Fashionista", openingHour: 9, closingHour: 21 },
  { name: "Bloemenwinkel Florista", openingHour: 8, closingHour: 18 },
  { name: "Supermarkt GoodFood", openingHour: 8, closingHour: 22 },
];

// Huidige uur ophalen
const currentHour = new Date().getHours();

// Div-referentie uit de HTML (de container waarin we winkels tonen)
const openShopsList = document.getElementById("openShopsList");

// Loop over alle shops voor dit uur
shops.forEach((shop) => {
  //Toon de winkelnaam en of deze open of gesloten is
  const shopP = document.createElement("p");
  // if open/closed
  if (currentHour >= shop.openingHour && currentHour < shop.closingHour) {
    shopP.style.color = "green";
    shopP.innerHTML = `<u>${shop.name}</u> is momenteel <u>open</u>.`;
  } else {
    shopP.style.color = "red";
    shopP.innerHTML = `<u>${shop.name}</u> is momenteel <u>gesloten</u>.`;
  }
  openShopsList.appendChild(shopP);
});

// functie om een winkel op te zoeken
function getShopInfoByName() {
  // Prompt voor de winkelnaam
  const userInput = prompt("Geef een winkelnaam op:");

  // Check of er wel iets is ingevuld
  if (!userInput) {
    // Als userInput null of leeg is (anders wordt altijd het eerste array-element getoond)
    console.log("Geen winkelnaam opgegeven");
    document.getElementById("openShopsList").innerHTML = "Geen winkelnaam opgegeven";
    return;
  }

  // Alles in lowercase om hoofdletter-ongevoelig te zoeken
  const searchLower = userInput.toLowerCase();

  // Zet standaard op Onbekende winkel (valt terug als we geen match vinden)
  let message = "Onbekende winkel";

  // Loop door de winkels
  for (let i = 0; i < shops.length; i++) {
    const shopNameLower = shops[i].name.toLowerCase();

    // indexOf(...) != -1 betekent dat de string voorkomt
    if (shopNameLower.indexOf(searchLower) !== -1) {
      message =
        `${shops[i].name} is open van ` +
        `${shops[i].openingHour} t.e.m. ${shops[i].closingHour} uur.`;
      break; // We kunnen stoppen na de eerste match
    }
  }

  // In console én in de paragraaf tonen
  console.log(message);
  const shopInfoP = document.createElement("p");
  shopInfoP.style.color = "grey";
  shopInfoP.innerHTML = message;

  // Vervang de bestaande kinderen door deze nieuwe paragraaf
  openShopsList.replaceChildren(shopInfoP);
}

// Ik heb het regelmatig nog moeilijk met de variable scoping; of liever gezegd -
// ik had de 'let message = "Onbekende winkel";' in de for-loop gezet, waardoor
// ik de waarde gewoon bleef overschrijven :D