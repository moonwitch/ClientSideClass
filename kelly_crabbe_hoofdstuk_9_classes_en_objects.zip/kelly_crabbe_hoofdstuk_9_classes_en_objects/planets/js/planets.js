class Planet {
  constructor(name,diameter,color,humanVisit) {
    this.name = name;
    this.diameter = diameter;
    this.color = color;
    this.humanVisit = humanVisit;
    this.radius = this.diameter / 2;
  };
  // Method to show the planet information
  showPlanetInfo() {
    const p = document.createElement("p");
    p.innerText = `De planeet ${this.name} heeft een diameter van ${this.diameter} km, een radius van ${this.radius} km, en is ${this.color}. ${
      this.humanVisit
        ? `Mensen hebben ${this.name} bezocht.`
        : `Mensen hebben ${this.name} nog niet bezocht.`
    }`;
    document.body.appendChild(p);
  };

  // Methode om een visuele representatie van de planeet te maken
  createVisualRepresentation() {
    const planet = document.createElement("div");
    planet.style.width = `${this.diameter / 100 }px`; // Schaal de grootte (bijvoorbeeld 1px = 50 km)
    planet.style.height = `${this.diameter / 100 }px`;
    planet.style.backgroundColor = this.color;
    planet.style.borderRadius = "50%"; // Maak de planeet cirkelvormig
    planet.style.display = "inline-block";
    planet.style.margin = "10px";
    document.body.appendChild(planet);
  }
}

// Maak de objecten aan
const mars = new Planet("Mars", 6779, "red", false);
const neptunus = new Planet("Neptunus", 49244, "lightblue", false);

// En gooi alles in de strijd :D
mars.showPlanetInfo();
neptunus.showPlanetInfo();

mars.createVisualRepresentation();
neptunus.createVisualRepresentation();