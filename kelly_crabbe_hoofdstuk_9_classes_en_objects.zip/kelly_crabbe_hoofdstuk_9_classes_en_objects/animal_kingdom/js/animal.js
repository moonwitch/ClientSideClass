class Animal {
    constructor(name, image, sound) {
        this.name = name;
        this.image = `./img/${image}.png`; // meteen de extension :D
        this.sound = `./audio/${sound}.mp3`; // meteen de extension :D
    }
    // method er bij voor het tonen van
    displayImage() {
        this.img = document.createElement('img');
        this.img.src = this.image;
        this.img.alt = this.name;
        this.img.style.width = '200px';

        // de onclick event toevoegen
        let animal_sound = new Audio(this.sound);
        this.img.addEventListener('click', function(){
            animal_sound.play();
        });

        // Ok superveel troubleshooting later :D
        // ik was vergeten om de img ook aan de body toe te voegen
        document.body.appendChild(this.img);
    }
}

// rework :D
const ANIMALS = [
    new Animal('Lion', 'lion', 'lion'),
    new Animal('Frog', 'frog', 'frog'),
    new Animal('Parrot', 'parrot', 'parrot')
];

// de dieren tonen
for (animal of ANIMALS) {
    animal.displayImage();
}