// Variables anc constants
// Ik weet dat jij meestal sequentieel vars en consts
// declareert, maar ik vind het overzichtelijker om ze
// te groeperen per type.
// Ik hoop dat dat ok is voor jou :)
const CAT = document.createElement('img');
const meow = new Audio("./audio/sound-effect-cat.mp3");
const bg_music = new Audio("./audio/cat-waltz.mp3");
// Oh god
let bg_music.loop = true;

// Add img + event listener to the DOM
CAT.src = './img/cat.jpg';
CAT.width = 400;
CAT.addEventListener('click', function() {
    meow.play();
});
document.body.appendChild(CAT);

// Add event listener for bg music
let isPlaying = false;
document.addEventListener('keydown', function(event) {
    if (event.key === ' ' || event.code === 'Space') {
        if (isPlaying) {
            bg_music.pause();
            isPlaying = false;
        } else {
            bg_music.play();
            isPlaying = true;
        }
    }
});